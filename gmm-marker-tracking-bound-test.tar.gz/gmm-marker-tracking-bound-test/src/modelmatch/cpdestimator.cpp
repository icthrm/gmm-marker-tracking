#include "cpdestimator.h"
#include "util/exception.h"
#include "matrix/matrix.h"
#include <cxcore.hpp>
#include <cv.hpp>
#include <cmath>
#include <numeric>

static void PrintPointSet(const std::vector<util::point2d>& pts)
{
	for(int i = 0; i < pts.size(); i++){
		std::cout<<pts[i].x<<" "<<pts[i].y<<std::endl;
	}
	std::cout<<std::endl;
}

void CPDEstimator::Normalizer::CalculateCenter(const std::vector< util::point2d >& pts, util::point2d& center)
{
	center.x = center.y = 0;		//calcuate the center of point set
	for(size_t i = pts.size(); i--;){  //for(size_t i = 0; i < pts.size(); i++){
		center.x += pts[i].x; center.y += pts[i].y;
	}
	
	center.x /= pts.size();
	center.y /= pts.size();
}

void CPDEstimator::Normalizer::CalculateScale(const std::vector< util::point2d >& pts, float* scale)
{
	//scale
	*scale = 0;
	for(size_t i = pts.size(); i--;){  //for(size_t i = 0; i < pts.size(); i++){
		*scale += pts[i].x*pts[i].x+pts[i].y*pts[i].y;
	}
	
	*scale /= pts.size();
	*scale = sqrt(*scale);
}

void CPDEstimator::Normalizer::MovePointSetToCenter(const util::point2d& center, std::vector< util::point2d >& pts)
{
	//move the point set to center
	for(size_t i = pts.size(); i--;){  //for(size_t i = 0; i < pts.size(); i++){		
		pts[i].x += center.x; pts[i].y += center.y;
	}
}

void CPDEstimator::Normalizer::ScalePointSet(const float scale, std::vector< util::point2d >& pts)
{
	for(size_t i = pts.size(); i--;){  //for(size_t i = 0; i < pts.size(); i++){		
		pts[i].x /= scale; pts[i].y /= scale;
	}
}

void CPDEstimator::Normalizer::GlobalNormalize(std::vector< util::point2d >& fixed, std::vector< util::point2d >& moving, 
									util::point2d& fixed_reverse_center, util::point2d& moving_reverse_center, float* scale)
{
	CalculateCenter(fixed, fixed_reverse_center);
	CalculateCenter(moving, moving_reverse_center);
	
	MovePointSetToCenter(util::point2d(-fixed_reverse_center.x, -fixed_reverse_center.y), fixed);
	MovePointSetToCenter(util::point2d(-moving_reverse_center.x, -moving_reverse_center.y), moving);
	
	float fixed_scale, moving_scale;
	CalculateScale(fixed, &fixed_scale);
	CalculateScale(moving, &moving_scale);
	*scale = max(fixed_scale, moving_scale);
	
	ScalePointSet(*scale, fixed);
	ScalePointSet(*scale, moving);
}

void CPDEstimator::Normalizer::ReverseNormalization(const util::point2d& reverse_center, float scale, std::vector< util::point2d >& points)
{
	ScalePointSet(1/scale, points);
	MovePointSetToCenter(reverse_center, points);
}

CPDEstimator::SearchTree::SearchTree(const std::vector< util::point2d >& fixed):nk(fixed.size()), psdim(2), pseps(ERROR_TOL), psNPts(fixed.size())
{
    psQryPt = annAllocPt(psdim); // query point
    psDataPts = annAllocPts(psNPts, psdim); // data points
    psNNIdx = new ANNidx[nk]; // near neighbor indices
    psDists = new ANNdist[nk]; // near neighbor distances

    for(int i = fixed.size(); i--;){
		psDataPts[i][0] = fixed[i].x;
		psDataPts[i][1] = fixed[i].y;
	}
	
	psKdTree = new ANNkd_tree(psDataPts, psNPts, psdim);
}

double* CPDEstimator::SearchTree::DistanceArray()
{
	return psDists;
}

int* CPDEstimator::SearchTree::IndicesArray()
{
	return psNNIdx;
}

void CPDEstimator::SearchTree::GetKNearestPoints(const util::point2d& quary, int k, int* indices, double* squared_distances)
{
	psQryPt[0] = quary.x;
	psQryPt[1] = quary.y;
	psKdTree->annkSearch(psQryPt, k, indices, squared_distances, pseps);
}

void CPDEstimator::SearchTree::GetRadiusNearestPoints(const util::point2d& quary, double radius, int* k, int* indices, double* squared_distances)
{
	psQryPt[0] = quary.x;
	psQryPt[1] = quary.y;
	*k = psKdTree->annkFRSearch(psQryPt, radius, 10/*psNPts*/, indices, squared_distances, pseps);
}

CPDEstimator::SearchTree::~SearchTree()
{
	delete [] psNNIdx;
    delete [] psDists;
    delete psKdTree;
    annDeallocPts(psDataPts);
    annDeallocPt(psQryPt);
}


double CPDEstimator::DefaultSigma2(const std::vector< util::point2d >& fixed, const std::vector< util::point2d >& moving)
{
	double tf = 0, tm = 0, sumfx = 0, sumfy = 0, summx = 0, summy = 0;
	int dim = 2;
	
	for(size_t i = fixed.size(); i--;){		//for(size_t i = 0; i < fixed.size(); i++){
		tf += fixed[i].x*fixed[i].x+fixed[i].y*fixed[i].y;
		sumfx += fixed[i].x; sumfy += fixed[i].y;
	}
	
	for(size_t i = moving.size(); i--;){		//for(size_t i = 0; i < moving.size(); i++){
		tm += moving[i].x*moving[i].x+moving[i].y*moving[i].y;
		summx += moving[i].x; summy += moving[i].y; 
	}
	
	return (moving.size()*tf+fixed.size()*tm-2*(sumfx*summx+sumfy*summy))/(fixed.size()*moving.size()*dim);
}

inline static float PT2DISTANCE(const util::point2d& a, const util::point2d& b)
{
	float deltax = ((a).x-(b).x);
	float deltay = ((a).y-(b).y);
	return deltax*deltax+deltay*deltay;
}

/** Given fixed PointSet (X) = the data points; moving PointSet (Y) = the GMM centroids;
 * 	X has N elements and Y has M elements;
 *  
 *  The GMM probability density function is:
 * 
 *  p(x)=sum_{m=1}^{M+1}{P(m)p(X|m)}
 *  p(x|m)=(2*pi*sigma^2 )^{-D/2}*exp{-(x-y_{m})^2/(2*sigma^2)}, D is the dimension
 *  P(m) respect the choice to choose the $m$th centroid; P(m)=M^{-1}
 * 
 * 	additional distribution p(x|M+1)=N^{-1} is added to represent noise and outliers
 *  priori(先验) for dataset and noise is defined as uniform distribution
 *  given weight w, we have:
 * 
 *  p(x)=w/N+(1-w)*sum_{m}^{M}{1/M*p(x|m)}
 * 
 *  use theta, sigma^2 denote the model, the MLE aim is:
 *  
 *  E(theta,sigma^2)=pow_{n=1}^{N}{p(x)}
 * 
 *  the log version of MLE aim is:
 *  
 *  E(theta,sigma^2)=sum_{n=1}^{N}{log{sum_{m=1}^{M+1}{P(m)p(X|m)}}}
 * 
 *  the correspondence probability between y_m and x_n:
 * 
 *  P(m|x_n)=P(m)p(x_n|m)/p(x_n)
 * 
 *  as EM method, our Estimation period: P^{old}(m|x_n)=P(m)p(x_n|m)/p(x_n)
 *  
 *  Q=-sum_{n=1}^{N}{sum_{m=1}^{M+1}{P^{old}(m|x_n)log(P^{new}(m)p^{new}(x_n|m))}}
 * 
 *  Q(theta,sigma^2)=(2*sigma^2)^{-1}*sum_{n=1}^{N}{sum_{m=1}^{M}{P^{old}(m|x_n)*(x_n-T(y_m,theta))^2}}+(N_p*D)/2*log(sigma^2)
 * 
 *  N_p=sum_{n=1}^{N}{sum_{m=1}^{M}{P^{old}(m|x_n)}} <= N
 * 
 *  P^{old}(m|x_n)=exp(-2^{-1}*((x_n-T(y_m,theta^{old}))/sigma)^2)/(sum_{k=1}^M{exp(-2^{-1}*((x_n-T(y_m,theta^{old}))/sigma)^2)}+c)
 * 
 *  c=(2*pi*sigma^2)^{D/2}*{w/(1-w)}*M/N
 * 
 * */
void CPDEstimator::ComputeDirectGaussTransform(const std::vector< util::point2d >& fixed, 
										  const std::vector< util::point2d >& moving, double sigma2, double outliers, Probabilities& probabilities)
{
	double ksig = -2.0 * sigma2;		//sigma2 <--> sigma^2
	double ksig_1 = 1/ksig;
    int dim = 2;				//dimension
    double c = (outliers*moving.size()*std::pow(-ksig*M_PI, 0.5*dim))/((1-outliers)*fixed.size());		// c = (w*M*(2*pi*sigma^2)^{D/2})/((1-w)*N)
    
    std::vector<double> p(moving.size(), 0);
	
    std::vector<double>& p1 =  *(new(&(probabilities.p1))std::vector<double>(moving.size(), 0));
    std::vector<double>& pt1 = *(new(&(probabilities.pt1))std::vector<double>(fixed.size(), 0));
	std::vector<util::point2d>& px = *(new(&(probabilities.px))std::vector<util::point2d>(moving.size(), util::point2d(0.0f, 0.0f)));
    double& l = probabilities.l = 0.0;
	
    for(size_t i = fixed.size(); i--;){			//for(size_t i = 0; i < fixed.size(); i++){		// n=1...N
        double sp = 0;

        for(size_t j = moving.size(); j--;){			//for(size_t j = 0; j < moving.size(); j++){		// m=1...M
            double razn = PT2DISTANCE(fixed[i], moving[j]); 	// (x_n-y_m)^2
            p[j] = std::exp(razn*ksig_1);			// p_{n=i,m=j}=exp{-(x_{n}-y_{m})^2/(2*sigma^2)}
            sp += p[j];
        }
        sp += c;		// sp_{n=i}=sum_{m=1}^{M}{exp{-(x_{n}-y_{m})^2/(2*sigma^2)}}+c
        double sp_1 = 1/sp;
        pt1[i] = 1 - c*sp_1;		// pt1_{n=i}=(sum_{m=1}^{M}{exp{-(x_{n}-y_{m})^2/(2*sigma^2)}})/(sum_{m=1}^{M}{exp{-(x_{n}-y_{m})^2/(2*sigma^2)}}+c)
        
        for(size_t j = moving.size(); j--;){			//for(size_t j = 0; j < moving.size(); ++j){		// m=1...M
			double pjsp_1 = p[j]*sp_1;
            p1[j] += pjsp_1;			//finally, p1_{m=j}=sum_{n=1}^{N}{exp{-(x_{n}-y_{m})^2/(2*sigma^2)}/(sum_{k=1}^{M}{exp{-(x_{n}-y_{k})^2/(2*sigma^2)}}+c)}
            px[j].x += fixed[i].x*pjsp_1; px[j].y += fixed[i].y*pjsp_1;
        }
        l += -std::log(sp);
    }
    l += dim * fixed.size() * std::log(sigma2) / 2;		//l <--> Q
}

void CPDEstimator::CalculateCorrespondence(const std::vector< util::point2d >& fixed, 
										  const std::vector< util::point2d >& moving, double sigma2, double outliers, std::vector<int>& correspondence)
{
	double ksig = -2.0 * sigma2;		//sigma2 <--> sigma^2
	double ksig_1 = 1/ksig;
    int dim = 2;				//dimension
    double c = (outliers*moving.size()*std::pow(-ksig*M_PI, 0.5*dim))/((1-outliers)*fixed.size());		// c = (w*M*(2*pi*sigma^2)^{D/2})/((1-w)*N)
    
    std::vector<double> p(moving.size(), 0);
	std::vector<double> p1_max(moving.size(), 0);
	
    new(&correspondence)std::vector<int>(moving.size());
	
    for(size_t i = fixed.size(); i--;){			//for(size_t i = 0; i < fixed.size(); i++){		// n=1...N
        double sp = 0;

        for(size_t j = moving.size(); j--;){			//for(size_t j = 0; j < moving.size(); j++){		// m=1...M
            double razn = PT2DISTANCE(fixed[i], moving[j]); 	// (x_n-y_m)^2
            p[j] = std::exp(razn*ksig_1);			// p_{n=i,m=j}=exp{-(x_{n}-y_{m})^2/(2*sigma^2)}
            sp += p[j];
        }
        sp += c;		// sp_{n=i}=sum_{m=1}^{M}{exp{-(x_{n}-y_{m})^2/(2*sigma^2)}}+c
        double sp_1 = 1/sp;
        
        for(size_t j = moving.size(); j--;){			//for(size_t j = 0; j < moving.size(); ++j){		// m=1...M
			double pjsp_1 = p[j]*sp_1;
			
            if(pjsp_1 > p1_max[j]){	//p[j]/sp<-->P(m=j|x_{n=i}); p1_max[j]<-->Maximum possibility 
                correspondence[j] = i;
                p1_max[j] = pjsp_1;
            }
        }
    }
}

double CPDEstimator::ComputeTreeGaussCorrelation(const std::vector< util::point2d >& fixed, const std::vector< util::point2d >& moving, double sigma2)
{
	double ksig = -2.0 * sigma2;		//sigma2 <--> sigma^2
	double thre = log(1.0 / ERROR_TOL)*sigma2;			//3*sigma threshold
	double ksig_1 = 1/ksig;
	double sp = 0;
	int k;
	int* indices = ftree.IndicesArray();
	double* dists = ftree.DistanceArray();
	
	for(size_t j = moving.size(); j--;){
		ftree.GetRadiusNearestPoints(moving[j], thre, &k, indices, dists);
		for(int i = k; i--;){
			sp += std::exp(dists[i]*ksig_1);
		}
	}
	return sp;
}

double CPDEstimator::ComputeDirectGaussCorrelation(const std::vector< util::point2d >& fixed, const std::vector< util::point2d >& moving, double sigma2)
{
	double ksig = -2.0 * sigma2;		//sigma2 <--> sigma^2
	double thre = 9 * sigma2;			//3*sigma threshold
	double ksig_1 = 1/ksig;
	double sp = 0;
	
	for(size_t i = fixed.size(); i--;){
		for(size_t j = moving.size(); j--;){
            double razn = PT2DISTANCE(fixed[i], moving[j]); 	// (x_n-y_m)^2
			if(razn > thre){
				continue;
			}
			sp += std::exp(razn*ksig_1);
		}
	}
	return sp;
}

void CPDEstimator::ComputeFastGaussTransform(const std::vector< util::point2d >& fixed, 
											 const std::vector< util::point2d >& moving, double sigma2, double outliers, Probabilities& prob)
{
	//sigma2 <--> sigma^2
	double ksig = -2.0 * sigma2;
    int dim = 2;		//dimension
    
    std::vector<double> a;
    
    ifgt::IFGaussianTransform ifgtm2f(moving, sqrt(2*sigma2), ERROR_TOL);
	ifgtm2f.CalculateTransformWith(fixed, a);
    double c = (outliers*moving.size()*std::pow(-ksig*M_PI, 0.5*dim))/((1-outliers)*fixed.size());		// c = (w*M*(2*pi*sigma^2)^{D/2})/((1-w)*N)
	
	new (&(prob.pt1))std::vector<double>(fixed.size());
	prob.l = 0;
	for(int i = a.size(); i--;){				//for(int i = 0; i < a.size(); i++){
		prob.pt1[i] = a[i]/(a[i]+c);
		prob.l += -std::log(a[i]+c);
		a[i] = 1/(a[i]+c);
	}
	prob.l += dim*fixed.size()*std::log(sigma2)/2;		//l <--> Q
	
	ifgt::IFGaussianTransform ifgtf2m(fixed, sqrt(2*sigma2), ERROR_TOL);
	ifgtf2m.CalculateTransformWith(moving, a, prob.p1);
	
	{
		std::vector<double> axy(fixed.size());
		for(int i = axy.size(); i--;){				//for(int i = 0; i < axy.size(); i++){
			axy[i] = a[i]*fixed[i].x;
		}
		
		std::vector<double> tmprslt;
		new (&(prob.px))std::vector<util::point2d>(moving.size());
		ifgtf2m.CalculateTransformWith(moving, axy, tmprslt);
		for(int i = prob.px.size(); i--;){			//for(int i = 0; i < prob.px.size(); i++){
			prob.px[i].x = tmprslt[i];
		}
		
		for(int i = axy.size(); i--;){		//for(int i = 0; i < axy.size(); i++){
			axy[i] = a[i]*fixed[i].y;
		}
		
		ifgtf2m.CalculateTransformWith(moving, axy, tmprslt);
		for(int i = prob.px.size(); i--;){		//for(int i = 0; i < prob.px.size(); i++){
			prob.px[i].y = tmprslt[i];
		}
	}
}

void CPDEstimator::MaximumStepAsRigidTransform(const std::vector<util::point2d>& fixed, const std::vector<util::point2d>& moving,
											   const Probabilities& probabilities, double sigma2, Params& result){
    int dim = 2;
	double np = 0;
	
	for(size_t i = 0; i < probabilities.pt1.size(); i++){
		np += probabilities.pt1[i];
	}
	
	util::point2d mu_x(0,0), mu_y(0,0);
	
	for(size_t i = 0; i < fixed.size(); i++){
		mu_x.x += fixed[i].x*probabilities.pt1[i]/np; mu_x.y += fixed[i].y*probabilities.pt1[i]/np;
	}
	
	for(size_t i = 0; i < moving.size(); i++){
		mu_y.x += moving[i].x*probabilities.p1[i]/np; mu_y.y += moving[i].y*probabilities.p1[i]/np;
	}

	double a[4];
	memset(a, 0, sizeof(double)*4);
	
	for(size_t i = 0; i < moving.size(); i++){
		a[0] += probabilities.px[i].x*moving[i].x;
		a[1] += probabilities.px[i].x*moving[i].y;
		a[2] += probabilities.px[i].y*moving[i].x;
		a[3] += probabilities.px[i].y*moving[i].y;
	}
	
	a[0] -= np*mu_x.x*mu_y.x;
	a[1] -= np*mu_x.x*mu_y.y;
	a[2] -= np*mu_x.y*mu_y.x;
	a[3] -= np*mu_x.y*mu_y.y;
	
	double u[4], c[4], s[4], vt[4], tmp[4];
	dgesvd_driver(2, 2, a, u, s, vt);
	s[3] = s[1]; s[1] = s[2] = 0; 		// define s as diagonal matrix;
	matrix_ident(2, c);
	matrix_product(2, 2, 2, 2, u, vt, tmp);
	c[0] = matrix_determinant2(tmp);
	
	double* R = &(result.p[0]);
	double* t = &(result.p[4]);
	
	//calculate R
	matrix_product(2, 2, 2, 2, u, c, tmp); matrix_product(2, 2, 2, 2, tmp, vt, R);
	
	if(false){	//calcuate scale or not
		matrix_product(2, 2, 2, 2, s, c, tmp);
		result.scale = tmp[0]+tmp[3];		//tmp trace
		
		double movxpx = 0;
		for(size_t i = 0; i < moving.size(); i++){
			movxpx += (moving[i].x*moving[i].x+moving[i].y*moving[i].y)*probabilities.p1[i];
		}
		
		result.scale /= movxpx-np*(mu_y.x*mu_y.x+mu_y.y*mu_y.y);
		
		result.sigma2 = 0;
		for(size_t i = 0; i < fixed.size(); i++){
			result.sigma2 += (fixed[i].x*fixed[i].x+fixed[i].y*fixed[i].y)*probabilities.pt1[i];
		}
		result.sigma2 = abs(result.sigma2-np*(mu_x.x*mu_x.x+mu_x.y*mu_x.y)-result.scale*(tmp[0]+tmp[3]))/(dim*np);
	}
	else{
		result.scale = 1.0;
		
		matrix_product(2, 2, 2, 2, s, c, tmp);
		
		result.sigma2 = 0;
		for(size_t i = 0; i < fixed.size(); i++){
			result.sigma2 += (fixed[i].x*fixed[i].x+fixed[i].y*fixed[i].y)*probabilities.pt1[i];
		}
		
		for(size_t i = 0; i < moving.size(); i++){
			result.sigma2 += (moving[i].x*moving[i].x+moving[i].y*moving[i].y)*probabilities.p1[i];
		}
		result.sigma2 -= np*(mu_x.x*mu_x.x+mu_x.y*mu_x.y+mu_y.x*mu_y.x+mu_y.y*mu_y.y)+2*(tmp[0]+tmp[3]);
		
		result.sigma2 /= (dim*np);
	}

	t[0] = mu_x.x-result.scale*(R[0]*mu_y.x+R[1]*mu_y.y);
	t[1] = mu_x.y-result.scale*(R[2]*mu_y.x+R[3]*mu_y.y);
}

void CPDEstimator::MaximumStepAsAffineTransform(const std::vector<util::point2d>& fixed, const std::vector<util::point2d>& moving,
											   const Probabilities& probabilities, double sigma2, Params& result){
    int dim = 2;
	double np = 0;
	
	for(size_t i = probabilities.pt1.size(); i--;){		//for(size_t i = 0; i < probabilities.pt1.size(); i++){
		np += probabilities.pt1[i];
	}
	
	util::point2d mu_x(0,0), mu_y(0,0);
	
	for(size_t i = fixed.size(); i--;){				//for(size_t i = 0; i < fixed.size(); i++){
		mu_x.x += fixed[i].x*probabilities.pt1[i]; mu_x.y += fixed[i].y*probabilities.pt1[i];
	}
	mu_x.x /= np; mu_x.y /= np;
	
	for(size_t i = moving.size(); i--;){			//for(size_t i = 0; i < moving.size(); i++){
		mu_y.x += moving[i].x*probabilities.p1[i]; mu_y.y += moving[i].y*probabilities.p1[i];
	}
	mu_y.x /= np; mu_y.y /= np;

	double b1[4], b2[4], tmp[4];
	memset(b1, 0, sizeof(double)*4);
	memset(b2, 0, sizeof(double)*4);
	
	for(size_t i = moving.size(); i--;){			//for(size_t i = 0; i < moving.size(); i++){
		b1[0] += probabilities.px[i].x*moving[i].x;
		b1[1] += probabilities.px[i].x*moving[i].y;
		b1[2] += probabilities.px[i].y*moving[i].x;
		b1[3] += probabilities.px[i].y*moving[i].y;
		
		b2[0] += probabilities.p1[i]*moving[i].x*moving[i].x;
		b2[1] += probabilities.p1[i]*moving[i].y*moving[i].x;
		b2[3] += probabilities.p1[i]*moving[i].y*moving[i].y;
	}
	
	b1[0] -= np*mu_x.x*mu_y.x;
	b1[1] -= np*mu_x.x*mu_y.y;
	b1[2] -= np*mu_x.y*mu_y.x;
	b1[3] -= np*mu_x.y*mu_y.y;
	
	b2[0] -= np*mu_y.x*mu_y.x;
	b2[1] -= np*mu_y.x*mu_y.y;
	b2[2] = b2[1];
	b2[3] -= np*mu_y.y*mu_y.y;
	
	double* A = &(result.p[0]);
	double* t = &(result.p[4]);
	
	matrix_invert_inplace(2, b2);
	matrix_product(2, 2, 2, 2, b1, b2, A);
	t[0] = mu_x.x - (A[0]*mu_y.x+A[1]*mu_y.y);
	t[1] = mu_x.y - (A[2]*mu_y.x+A[3]*mu_y.y);
	
	result.scale = 1.0;
	
	result.sigma2 = 0;
	for(size_t i = fixed.size(); i--;){			//for(size_t i = 0; i < fixed.size(); i++){
		result.sigma2 += (fixed[i].x*fixed[i].x+fixed[i].y*fixed[i].y)*probabilities.pt1[i];
	}

	result.sigma2 -= np*(mu_x.x*mu_x.x+mu_x.y*mu_x.y)+(b1[0]*A[0]+b1[1]*A[1]+b1[2]*A[2]+b1[3]*A[3]);
	result.sigma2 /= dim*np;
}

void CPDEstimator::UpdatePointSet(const std::vector< util::point2d >& ori, const CPDEstimator::Params& params, std::vector< util::point2d >& result)
{
	result = std::vector<util::point2d>(ori.size());
	const double* R = &(params.p[0]);
	const double* t = &(params.p[4]);
	
	for(size_t i = ori.size(); i--;){			//for(size_t i = 0; i < ori.size(); i++){
		result[i].x = (ori[i].x*R[0]+ori[i].y*R[1])+t[0];//params.scale*(ori[i].x*R[0]+ori[i].y*R[1])+t[0];
		result[i].y = (ori[i].x*R[2]+ori[i].y*R[3])+t[1];//params.scale*(ori[i].x*R[2]+ori[i].y*R[3])+t[1];
	}
}

void CPDEstimator::FromCorrespondenceToMatch(const std::vector< util::point2d >& fixed, const std::vector< util::point2d >& moving, 
											 std::vector< int >& correspondence, std::vector< std::pair< int, int > >& rawmatches, double dist_err_tol) const
{
	float dist_err_thre = dist_err_tol*dist_err_tol;
	rawmatches.clear();
	for(int i = 0; i < correspondence.size(); i++){
		if(PT2DISTANCE(fixed[correspondence[i]], moving[i]) < dist_err_thre){
			rawmatches.push_back(std::make_pair(correspondence[i], i));
		}
	}
}

double CPDEstimator::GetMaxDiscernibleSigma(const std::vector<util::point2d>& pts1, const std::vector<util::point2d>& pts2)
{	
	SearchTree ref(pts1);
	int* idices = ref.IndicesArray();
	double* dists = ref.DistanceArray();
	double avg_dist = 0;
	
	for(int i = pts2.size(); i--;){
		ref.GetKNearestPoints(pts2[i], 2, idices, dists);
		if(&pts1 == &pts2){
			avg_dist += sqrt(dists[1]);
		}
		else{
			avg_dist += sqrt(dists[0]);
		}
	}
	avg_dist /= pts2.size();
	
	return avg_dist*.333333333333;//.2;		//2.5*sigma*2 = avg_dist or 1.5*sigma*2 = avg_dist
}

inline static void UpdatePointSetByCoarseParam(const std::vector<util::point2d>& moving, double alpha, double t0, double t1, std::vector<util::point2d>& nmoving)
{
	float calpha = cos(alpha);
	float salpha = sin(alpha);
	float A[4];
	A[0] = calpha; A[1] = salpha; A[2] = -salpha; A[3] = calpha;
	util::point2d tpt;
	
	for(int idx = nmoving.size(); idx--;){
		tpt.x = moving[idx].x+t0;
		tpt.y = moving[idx].y+t1;
		nmoving[idx].x = tpt.x*A[0]+tpt.y*A[1];
		nmoving[idx].y = tpt.x*A[2]+tpt.y*A[3];
	}
}

void CPDEstimator::CoarseAlignmentByGMM(const std::vector< util::point2d >& fixed, std::vector< util::point2d >& moving, double sigma2, Params& param, double step_ratio)
{
#define PI_180				0.0174532925199433
#define SPAN				0.65
	double grid_step = step_ratio*sqrt(sigma2);//2.5*sqrt(sigma2);		//grid_step = 2.5*sigma
	double angle_step = atan(grid_step);
	double corr, max_corr = -1;
	
	std::vector<util::point2d> nmoving(moving.size());
// 	EX_TRACE("coarse search grid step = %0.2lfpx, angle step = %0.2lf\n", grid_step*scale, angle_step/PI_180);
	
	for(double t0 = -SPAN; t0 < SPAN; t0 += grid_step){
		for(double t1 = -SPAN; t1 < SPAN; t1 += grid_step){
			for(double alpi = -0.523598775598299; alpi < 0.523598775598299; alpi += angle_step){		//30*pi/180 = 0.523598775598299
				UpdatePointSetByCoarseParam(moving, alpi, t0, t1, nmoving);
// 				corr = ComputeDirectGaussCorrelation(fixed, nmoving, sigma2);
				corr = ComputeTreeGaussCorrelation(fixed, nmoving, sigma2);
				if(corr > max_corr){
					max_corr = corr;
					param.p[3] = alpi;
					param.p[4] = t0;
					param.p[5] = t1;
				}
			}
		}
	}
// 	std::cout<<max_corr<<std::endl;
	UpdatePointSetByCoarseParam(moving, param.p[3], param.p[4], param.p[5], nmoving);
	moving = nmoving;
	double tmp[2];
	param.p[0] = cos(param.p[3]); param.p[1] = sin(param.p[3]); 
	param.p[2] = -param.p[1]; param.p[3] = param.p[0];
	tmp[0] = param.p[0]*param.p[4]+param.p[1]*param.p[5];
	tmp[1] = param.p[2]*param.p[4]+param.p[3]*param.p[5];
	param.p[4] = tmp[0]; param.p[5] = tmp[1];
// 	PrintPointSet(moving);
}

void CPDEstimator::CoarseAlignmentByGMM2(const std::vector< util::point2d >& fixed, std::vector< util::point2d >& moving, double sigma2, CPDEstimator::Params& param, double step_ratio)
{
#define PI_180				0.0174532925199433
#define SPAN				0.65
	double grid_step = step_ratio*sqrt(sigma2);//2.5*sqrt(sigma2);		//grid_step = 2.5*sigma
	double angle_step = atan(grid_step);
	double corr, max_corr = -1;
	
	double cos_beta1 = cos(beta1*PI_180), cos_beta2 = cos(beta2*PI_180); 
	
	std::vector<util::point2d> nmoving(moving.size());
// 	EX_TRACE("coarse search grid step = %0.2lfpx, angle step = %0.2lf\n", grid_step*scale, angle_step/PI_180);
	
	for(double t0 = -SPAN; t0 < SPAN; t0 += grid_step){
		for(double t1 = -SPAN; t1 < SPAN; t1 += grid_step){
			for(double alpi = -0.523598775598299; alpi < 0.523598775598299; alpi += angle_step){		//30*pi/180 = 0.523598775598299
				for(double alpi2 = -0.523598775598299; alpi2 < 0.523598775598299; alpi2 += angle_step){		//30*pi/180 = 0.523598775598299
					double hmx[] = {cos_beta1/cos_beta2, 0, 0, 1};
					double alpi1mx[4], alpi2mx[4];
					alpi1mx[3] = alpi1mx[0] = cos(alpi);
					alpi1mx[2] = -(alpi1mx[1] = sin(alpi)); 
					alpi2mx[3] = alpi2mx[0] = cos(alpi2);
					alpi2mx[2] = -(alpi2mx[1] = sin(alpi2));
					double tmp[4];
					Params tparams;
					matrix_product(2, 2, 2, 2, hmx, alpi2mx, tmp);
					matrix_product(2, 2, 2, 2, alpi1mx, tmp, tparams.p);
					tparams.p[4] = tparams.p[0]*t0+tparams.p[1]*t1;
					tparams.p[5] = tparams.p[2]*t0+tparams.p[3]*t1;
					UpdatePointSet(moving, tparams, nmoving);
	// 				corr = ComputeDirectGaussCorrelation(fixed, nmoving, sigma2);
					corr = ComputeTreeGaussCorrelation(fixed, nmoving, sigma2);
					if(corr > max_corr){
						max_corr = corr;
						memcpy(param.p, tparams.p, sizeof(double)*6);
					}
				}
			}
		}
	}
// 	std::cout<<max_corr<<std::endl;
	UpdatePointSet(moving, param, nmoving);
	moving = nmoving;

// 	PrintPointSet(moving);
}

bool CPDEstimator::GaussianMixedModelMatch(double dist_err_tol, std::vector< std::pair< int, int > >& matches, bool eigenlimit)
{
	if((int)fixed.size() < MIN_PT_NUM || (int)fixed.size() < MIN_PT_NUM){
		EX_TRACE("Insufficient number of fiducial markers\n");
		return false;
	}
	
	double sigf = GetMaxDiscernibleSigma(fixed, fixed);
	double sigm = GetMaxDiscernibleSigma(moving, moving);
	default_sigma2 = pow(min(sigf, sigm), 2);
	double step_ratio = 2.5;
	
	bool solved = false;
	while(!solved){
// 		PrintPointSet(fixed);
// 		PrintPointSet(moving);
		
		CoarseAlignmentByGMM2(fixed, moving, default_sigma2, cos_params, step_ratio);
		
// 		PrintPointSet(moving);
		
		Probabilities probabilities;
		points = moving;
		
		if (default_sigma2 == -1) {
			fin_params.sigma2 = DefaultSigma2(fixed, moving);
		}
		else{
			fin_params.sigma2 = default_sigma2;
		}
		
		size_t iter = max_iter;
		double ntol = cpd_err_tol + 10.0;
		double l = 0.;
		
		while(iter && ntol > cpd_err_tol && fin_params.sigma2 > 10*__DBL_EPSILON__){
			ComputeDirectGaussTransform(fixed, points, fin_params.sigma2, outliers_weight, probabilities);
			
			ntol = abs((probabilities.l - l)/probabilities.l);
			l = probabilities.l;

			MaximumStepAsAffineTransform(fixed, moving, probabilities, fin_params.sigma2, fin_params);
// 				MaximumStepAsRigidTransform(fixed, moving, probabilities, params.sigma2, params);
			UpdatePointSet(moving, fin_params, points);
			iter--;
		}
		
// 		PrintPointSet(points);
		
		CalculateCorrespondence(fixed, points, fin_params.sigma2, outliers_weight, correspondence);
		
		if(eigenlimit){	
			double evec[4], eval[2];
			dgeev_driver(2, fin_params.p, evec, eval);
			if(eval[0] < 0.8 || eval[1] < 0.8 || eval[0] > 1.25 || eval[1] > 1.25){		// it is not a correct transform
				step_ratio *= 0.5;
				continue;
			}
		}
		
		FromCorrespondenceToMatch(fixed, points, correspondence, matches, dist_err_tol*1.25);		//a relax of threshold
		if(matches.size() < 5 || (matches.size() < 9 && matches.size() < fixed.size()*COVERAGE_REFRESH_RATIO*.25 &&  matches.size() < moving.size()*COVERAGE_REFRESH_RATIO*.25)){
			step_ratio *= 0.5;		// in the case of incorrect start point
			if(step_ratio < 0.5){
				return false;		//we failed 
			}
		}
		else{
			solved = true;
		}
	}
	// 	std::cout<<matches.size()<<std::endl;	
	return true;
}

void CPDEstimator::MiniOptimizeByGMM(const std::vector< util::point2d >& fixed, const std::vector< util::point2d >& moving, 
									 double dist_err_tol, std::vector< std::pair< int, int > >& matches, bool eigenlimit)
{
	Probabilities probabilities;
	points = moving;
	size_t iter = max_iter;
	double ntol = cpd_err_tol + 10.0;
	double l = 0.;
	
	double sigf = GetMaxDiscernibleSigma(fixed, fixed);
	double sigm = GetMaxDiscernibleSigma(moving, moving);
	fin_params.sigma2 = pow(min(sigf, sigm), 2);
	matches.clear();
// 	fin_params.sigma2 = default_sigma2;
	
// 	PrintPointSet(fixed);
// 	PrintPointSet(moving);
	
	while(iter && ntol > cpd_err_tol && fin_params.sigma2 > 10*__DBL_EPSILON__){
		ComputeDirectGaussTransform(fixed, points, fin_params.sigma2, outliers_weight, probabilities);
		
		ntol = abs((probabilities.l - l)/probabilities.l);
		l = probabilities.l;

		MaximumStepAsAffineTransform(fixed, moving, probabilities, fin_params.sigma2, fin_params);
// 			MaximumStepAsRigidTransform(fixed, moving, probabilities, params.sigma2, params);
		UpdatePointSet(moving, fin_params, points);
		iter--;
	}
	
	if(isnan(fin_params.sigma2)){
		return;
	}
	
// 	PrintPointSet(points);
	
	CalculateCorrespondence(fixed, points, fin_params.sigma2, outliers_weight, correspondence);
	
	double evec[4], eval[2];
	dgeev_driver(2, fin_params.p, evec, eval);
	
	if(eigenlimit){
		if(eval[0] < 0.8 || eval[1] < 0.8 || eval[0] > 1.25 || eval[1] > 1.25){		// it is not a correct transform
			return;
		}
	}
	
	FromCorrespondenceToMatch(fixed, points, correspondence, matches, dist_err_tol);
}

CPDEstimator::CPDEstimator(const std::vector<util::point2d>& __fids1, const std::vector<util::point2d>& __fids2): ori_fixed(__fids1), ori_moving(__fids2), 
						fixed(__fids1), moving(__fids2), default_sigma2(DEFAULT_SIGMA2), cpd_err_tol(ERROR_TOL), outliers_weight(OUTLIERS_WEIGHT), max_iter(MAX_CPD_ITERATION)
{
	Normalizer::GlobalNormalize(fixed, moving, fixed_center, moving_center, &scale);
	new (&ftree) SearchTree(fixed);
}

void CPDEstimator::CalculateMatch(const std::vector< util::point2d >& fids1, const std::vector< util::point2d >& fids2,
									   std::vector< std::pair<int, int> >& rawmatches, std::vector<double>& dists, double dist_err_tol)
{
	SearchTree ref(fids1);
	int* idices = ref.IndicesArray();
	double* distances = ref.DistanceArray();
	float dist_err_thre = dist_err_tol*dist_err_tol;
	
	rawmatches.clear();
	dists.clear();
	
	for(int i = fids2.size(); i--;){
		ref.GetKNearestPoints(fids2[i], 1, idices, distances);
		if(distances[0] < dist_err_thre){
			rawmatches.push_back(std::make_pair(idices[0], i));
			dists.push_back(distances[0]);
		}
	}
}

/**
 * |a b|  |t0|
 * |c d|  |t1|

/**xf=params:[a b c d t0 t1]*/
void CPDEstimator::ComputeTransformByLeastSquares(const std::vector< util::point2d >& fixed, const std::vector< util::point2d >& moving, 
												  const std::vector< std::pair< int, int > >& matches, CPDEstimator::Params& params)
{
	size_t n = matches.size();
	int num_eqs = 2*n;
    int num_vars = 6;

    double *As = new double[num_eqs*num_vars];
    double *bs = new double[num_eqs];

    for(size_t i = n; i--;){
        double* A = As+12*i;
        double* b = bs+2*i;
		
        A[0] = moving[matches[i].second].x; A[1] = moving[matches[i].second].y; A[2] = 0; A[3] = 0; A[4] = 1; A[5] = 0;
		A[6] = 0; A[7] = 0; A[8] = moving[matches[i].second].x; A[9] = moving[matches[i].second].y; A[10] = 0; A[11] = 1;
        b[0] = fixed[matches[i].first].x;
        b[1] = fixed[matches[i].first].y;
    }
    
    dgelsy_driver(As, bs, params.p, num_eqs, num_vars, 1);

	delete [] As;
	delete [] bs;
}

static bool pairCompare(const std::pair<double, int>& firstElem, const std::pair<double, int>& secondElem){
  return firstElem.first < secondElem.first;
}

void CPDEstimator::SetSupplementData(double beta1, double beta2)
{
	this->beta1 = beta1; this->beta2 = beta2;
}

void CPDEstimator::GlobalMatch(double dist_err_tol, std::vector< std::pair< util::point2d, util::point2d > >& matchvec, std::vector< CvMat* >& hset, bool test, bool eigenlimit)
{
	pts_dist_tol = dist_err_tol/scale;
	
	std::vector<std::pair<int, int> > matches;
	
	if(!GaussianMixedModelMatch(pts_dist_tol, matches, eigenlimit)){
		return;
	}
	
	std::vector<util::point2d> nfixed = fixed;				//used for calculation
	std::vector<util::point2d> nmoving = moving;			//used for calculation
	std::vector<util::point2d> norif = ori_fixed;			//used for datasaving
	std::vector<util::point2d> norim = ori_moving;			//used for datasaving
	
	std::vector<std::vector< std::pair< util::point2d, util::point2d > > > pairsets;
	std::vector<Params> pvec;
	
	std::vector<std::pair< util::point2d, util::point2d > > prepairs;
	
	bool split_pointset = true; bool first_itr = true;
	double dist_err_thre = pts_dist_tol*pts_dist_tol;		//square distance error
	
	while(split_pointset){
		Params nparams;
		std::vector<std::pair<int, int> > indices;
		std::vector<std::pair<int, int> > premidices;
		std::vector<std::pair<int, int> > nmatches;
		
		if(matches.size() < 6){					//there are no matches any more
			pairsets[pairsets.size()-1].insert(pairsets[pairsets.size()-1].end(), prepairs.begin(), prepairs.end());
			break;
		}
		
		if(!first_itr){
			std::vector<util::point2d> tfixed(matches.size()), tmoving(matches.size());
			std::vector<int> tforidx(matches.size()), tmoridx(matches.size());
			for(int i = 0; i < matches.size(); i++){
				tfixed[i] = nfixed[matches[i].first];
				tforidx[i] = matches[i].first;
				tmoving[i] = nmoving[matches[i].second];
				tmoridx[i] = matches[i].second;
			}
			MiniOptimizeByGMM(tfixed, tmoving, pts_dist_tol, matches, eigenlimit);		//used to solve uncertain assign problem
			for(int i = 0; i < matches.size(); i++){
				matches[i].first = tforidx[matches[i].first];
				matches[i].second = tmoridx[matches[i].second];
			}
			if(matches.size() < 6){				//it indicates that the remains are with bad distribution
				break;
			}
		}
		
		ComputeTransformByLeastSquares(nfixed, nmoving, matches, nparams);	//!WORNING use GMMaffine?
		
		UpdatePointSet(nmoving, nparams, points);
		
		std::vector<double> dists;
		CalculateMatch(nfixed, points, matches, dists, pts_dist_tol*2);	//get all the possible matches
		
		if(first_itr){		//used to calculate the CPD match error
			double deviation;
			int count = 0;
			for(int i = 0; i < dists.size(); i++){
				double dist = sqrt(dists[i]);
				if(dist < pts_dist_tol*1.2){
					deviation += dist;
					count++;
				}
			}
// 			std::cout<<"Initial mean deviation: ["<<deviation*scale/count<<","<<count<<"]"<<std::endl;
		}
		
// 		std::cout<<matches.size()<<std::endl;
		
		std::vector<std::pair<double, int> > candidates;
		for(int i = 0; i < matches.size(); i++){
			candidates.push_back(std::make_pair(dists[i], i));
		}
		
		std::sort(candidates.begin(), candidates.end(), pairCompare);
		
// 		for(int j = 0; j < points.size(); j++){
// 			bool found = false;
// 			for(int i = 0; i <= 10; i++){
// 				if(j == matches[candidates[i].second].second){
// 					found = true;
// 					break;
// 				}
// 			}
// 			if(found){
// 				continue;
// 			}
// 			std::cout<<points[j].x<<" "<<points[j].y<<std::endl;
// 		}
// 		
// 		std::cout<<std::endl;
// 		
// 		for(int i = 0; i < candidates.size(); i++){
// 			std::cout<<points[matches[candidates[i].second].second].x<<" "<<points[matches[candidates[i].second].second].y<<std::endl;
// 		}
// 		std::cout<<std::endl;
		
		if(!candidates.size()){
			break;
		}
		else if(candidates[candidates.size()-1].first < dist_err_thre){		//the two point sets have no warp
			indices = matches;
			pvec.push_back(nparams);
			split_pointset = false;
			prepairs.clear();
		}
		else{
			prepairs.clear();
			
			int candix;
			double warp_dist_err_thre = pts_dist_tol*pts_dist_tol*.75*.75;
			
			for(candix = candidates.size(); candix--;){
				if(candidates[candix].first < warp_dist_err_thre){			//find the point pairs that are close enough
					break;
				}
				if(candidates[candix].first < dist_err_thre){				//save the matches between thre*.75 and thre in the case that next routine failed
					premidices.push_back(matches[candidates[candix].second]);
				}
			}
			if(candix < 3){
				break;
			}
			
// 			std::cout<<"premidices: "<<premidices.size()<<std::endl;
// 			std::cout<<"candix: "<<candix<<std::endl;
			
			for(int i = candix+1; i < candidates.size(); i++){				//next turn's seed;
				nmatches.push_back(matches[candidates[i].second]);
			}
			
			for(int idx = candix+1; idx--;){
				indices.push_back(matches[candidates[idx].second]);
			}
			pvec.push_back(nparams);
		}
		
		std::vector< std::pair< util::point2d, util::point2d > > pairs;
		for(int i = 0; i < indices.size(); i++){
			pairs.push_back(std::make_pair(norif[indices[i].first], norim[indices[i].second]));
		}
		
		pairsets.push_back(pairs);
		
		for(int i = 0; i < premidices.size(); i++){
			prepairs.push_back(std::make_pair(norif[premidices[i].first], norim[premidices[i].second]));
		}
		
		std::vector<util::point2d> tfixed, torif; 
		for(int i = 0; i < nfixed.size(); i++){
			bool find = false;
			for(int j = 0; j < indices.size(); j++){
				if(indices[j].first == i){
					find = true;
					break;
				}
			}
			if(!find){
				tfixed.push_back(nfixed[i]);
				torif.push_back(norif[i]);
			}
			for(int j = 0; j < nmatches.size(); j++){
				if(nmatches[j].first == i){
					nmatches[j].first = tfixed.size()-1;
				}
			}
		}
		nfixed = tfixed; norif = torif;

		std::vector<util::point2d> tmoving, torim;
		for(int i = 0; i < nmoving.size(); i++){
			bool find = false;
			for(int j = 0; j < indices.size(); j++){
				if(indices[j].second == i){
					find = true;
					break;
				}
			}
			if(!find){
				tmoving.push_back(nmoving[i]);
				torim.push_back(norim[i]);
			}
			for(int j = 0; j < nmatches.size(); j++){
				if(nmatches[j].second == i){
					nmatches[j].second = tmoving.size()-1;
				}
			}
		}
		nmoving = tmoving; norim = torim;
		
		matches = nmatches;
		first_itr = false;
	}

	matchvec.clear();
	for(int i = 0; i < pairsets.size(); i++){
		std::vector<std::pair<util::point2d, util::point2d> >& mm = pairsets[i];
		matchvec.insert(matchvec.end(), mm.begin(), mm.end());
	}

	hset.clear();
	double A[4], t[2];
	for(int i = 0; i < pvec.size(); i++){			// change the transform matrix according to the coordinate of ori point sets
		A[0] = pvec[i].p[0]*cos_params.p[0]+pvec[i].p[1]*cos_params.p[2];
		A[1] = pvec[i].p[0]*cos_params.p[1]+pvec[i].p[1]*cos_params.p[3];
		A[2] = pvec[i].p[2]*cos_params.p[0]+pvec[i].p[3]*cos_params.p[2];
		A[3] = pvec[i].p[2]*cos_params.p[1]+pvec[i].p[3]*cos_params.p[3];
		t[0] = pvec[i].p[4]; 
		t[1] = pvec[i].p[5];
		t[0] += pvec[i].p[0]*cos_params.p[4]+pvec[i].p[1]*cos_params.p[5];
		t[1] += pvec[i].p[2]*cos_params.p[4]+pvec[i].p[3]*cos_params.p[5];
		t[0] *= scale; t[1] *= scale;
		t[0] += -A[0]*moving_center.x-A[1]*moving_center.y+fixed_center.x;
		t[1] += -A[2]*moving_center.x-A[3]*moving_center.y+fixed_center.y;
		memcpy(pvec[i].p, A, sizeof(double)*4);
		memcpy(pvec[i].p+4, t, sizeof(double)*2);
		
		CvMat* h = cvCreateMat(3, 3, CV_64FC1);
		cvmSet(h,0,0,A[0]); cvmSet(h,0,1,A[1]); cvmSet(h,0,2,t[0]);
		cvmSet(h,1,0,A[2]); cvmSet(h,1,1,A[3]); cvmSet(h,1,2,t[1]);
		cvmSet(h,2,0,0); cvmSet(h,2,1,0); cvmSet(h,2,2,1);
		
		cvInvert(h, h);			//compatible with random 4 points methods
		
		hset.push_back(h);
	}
	
// 	PrintPointSet(ori_fixed);
// 	PrintPointSet(ori_moving);
// 	UpdatePointSet(ori_moving, pvec[0], points);
// 	PrintPointSet(points);
}


// void CPDEstimator::EstimateAffineGMMTransform(std::vector< util::point2d >& fixed, std::vector< util::point2d >& moving)
// {
// 	util::point2d fixed_center, moving_center;
// 	float scale;
// 	Normalizer::GlobalNormalize(fixed, moving, fixed_center, moving_center, &scale);
// 	
// 	Probabilities probabilities;
// 	points = moving;
// 	
// 	if(default_sigma2 == -1){
// 		params.sigma2 = DefaultSigma2(fixed, moving);
// 	}
// 	else{
// 		params.sigma2 = default_sigma2;
// 	}
// 	
// 	size_t iter = max_iter;
// 	double ntol = cpd_err_tol + 10.0;
// 	double l = 0.;
// 	
// 	while(iter && ntol > cpd_err_tol && params.sigma2 > 10*__DBL_EPSILON__){
// 		std::cout<<params.sigma2<<std::endl;
// 		ComputeDirectGaussTransform(fixed, points, params.sigma2, outliers_weight, probabilities);
// 		
// 		ntol = abs((probabilities.l - l)/probabilities.l);
// 		std::cout<<l<<std::endl;
// 		l = probabilities.l;
// 
// 		MaximumStepAsAffineTransform(fixed, moving, probabilities, params.sigma2, params);
// // 			MaximumStepAsRigidTransform(fixed, moving, probabilities, params.sigma2, params);
// 		UpdatePointSet(moving, params, points);
// 		iter--;
// 	}
// 	
// 	CalculateCorrespondence(fixed, points, params.sigma2, outliers_weight, correspondence);
// 	
// 	Normalizer::ReverseNormalization(fixed_center, scale, points);
// 	Normalizer::ReverseNormalization(fixed_center, scale, fixed);
// 	Normalizer::ReverseNormalization(moving_center, scale, moving);
// }

